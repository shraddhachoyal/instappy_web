export class PasswordChange {
    uid!: Number;
    password!: string;
}
