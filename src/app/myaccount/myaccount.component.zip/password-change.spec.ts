import { PasswordChange } from './password-change';

describe('PasswordChange', () => {
  it('should create an instance', () => {
    expect(new PasswordChange()).toBeTruthy();
  });
});
