export class Register {
    fullname!:string;
    email!:string;
    companyname!:string;
    message!:string
  }
