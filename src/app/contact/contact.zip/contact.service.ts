import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams} from '@angular/common/http'
import { apiURL } from 'src/environments/environment';
import { from, Observable } from 'rxjs';
import { Register } from "./register";
import * as $ from 'jquery'
@Injectable({
  providedIn: 'root'
})

export class ContactService {
  constructor(private httpClient: HttpClient) { }
  private authUrl = apiURL;

  CreateUser(register:Register)
   {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.httpClient.post<Register[]>(this.authUrl + 'addcontactform/', register, httpOptions)
   }
}
