import { Component, OnInit } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { ContactService } from './contact.service';
import {Register} from './register';
import {Observable} from 'rxjs';
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit  {

  data = false;
  UserForm!: FormGroup;
  message: string | undefined;
  submitted = false;
  showMessage: boolean=false;
  error: string | any;
  constructor( private formBuilder: FormBuilder,private contactService:ContactService,private spinner: NgxSpinnerService ) { 
    /*this.UserForm = this.formbuilder.group({
      fullname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      companyname: ['', Validators.required],
      message: ['', Validators.required],
      acceptTerms: ['', Validators.required],
      
    });*/
  }
  //get contactform() { return this.UserForm.controls; }

  ngOnInit() { 

    this.UserForm = this.formBuilder.group({
      fullname: [
        "",
        [Validators.required, this.nameValidation, this.noWhitespaceValidator]
      ],
      email: [
        "",
        [Validators.required, this.emailValidation, this.noWhitespaceValidator]
      ],
      companyname: [
        "",
        [
          Validators.required,
          this.noWhitespaceValidator
        ]
      ],
      message: ['', Validators.required],
      acceptTerms: ['', Validators.required],
     
    });
    
   }
   get contactform() { return this.UserForm.controls; }

   public nameValidation(control: FormGroup) {
    let value = control.value;
    var regex = new RegExp("^[a-zA-Z ]+$");
    let isValidCode = regex.test(value);
    return isValidCode == true ? null : { notaname: true };
  }

  public noWhitespaceValidator(control: FormGroup) {
		let isWhitespace = (control.value || '').trim().length === 0;
		let isValid = !isWhitespace;
		return isValid ? null : { 'whitespace': true }
  }

  public emailValidation(control: FormGroup) {
    let value = control.value;
    var regex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    let isValidCode = regex.test(value);
    return isValidCode == true ? null : { notanemail: true };
  }
   
  /*onFormSubmit()
  {
    this.submitted = true;
    const user = this.UserForm.value;
    this.Createemployee(user);
  }
  Createemployee(register:Register)
  {
  this.contactService.CreateUser(register).subscribe(
    ()=>
    {
      this.data = true;
      this.message = 'Data saved Successfully';
      this.UserForm.reset();
    });
  }*/

  onFormSubmit() {
    this.submitted = true;
     let formdata = this.UserForm.value
    if (this.UserForm.invalid) {
        return;
    }
    else
    {
      this.spinner.show();
      this.contactService.CreateUser(formdata).subscribe(data=>{
        this.showMessage = true;
        this.submitted = false; 
        this.UserForm.reset();
        this.UserForm.controls.enq_type.setValue("");
        setTimeout(() => {
          this.spinner.hide();
          this.showMessage = false;     
        }, 3000);
      });
    }

   
}

}
