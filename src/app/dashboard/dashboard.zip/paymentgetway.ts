export class Paymentgetway {
}
