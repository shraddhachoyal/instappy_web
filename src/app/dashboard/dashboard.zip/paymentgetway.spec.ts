import { Paymentgetway } from './paymentgetway';

describe('Paymentgetway', () => {
  it('should create an instance', () => {
    expect(new Paymentgetway()).toBeTruthy();
  });
});
