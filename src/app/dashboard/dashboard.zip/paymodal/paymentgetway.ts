export class Paymentgetway {
    app_uid!: string;
    gateway_name!: string;
    key!: string;
    secret_key!: string;
}
