import { Bannercat } from './bannercat';

describe('Bannercat', () => {
  it('should create an instance', () => {
    expect(new Bannercat()).toBeTruthy();
  });
});
