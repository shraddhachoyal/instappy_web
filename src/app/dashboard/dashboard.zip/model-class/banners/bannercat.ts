export class Bannercat {
    app_uid!: string;
    banner_name!: string;
    category_name!: string;
    category_image!: string;
}
