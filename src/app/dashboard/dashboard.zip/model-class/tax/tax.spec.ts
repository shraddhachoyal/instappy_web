import { Tax } from './tax';

describe('Tax', () => {
  it('should create an instance', () => {
    expect(new Tax()).toBeTruthy();
  });
});
