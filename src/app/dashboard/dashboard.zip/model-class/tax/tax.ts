export class Tax {
    app_uid!: string;
    country_name!: string;
    tax_rate!: string;
}
