export class Docommission {
    commission!: any
    document!: any
    app_uid!: string
}
