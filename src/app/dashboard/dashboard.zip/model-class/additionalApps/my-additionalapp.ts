export class MyAdditionalapp {
    app_name!: any;
    // colar_type!: string;
    // color_code!: any;
    // icon_type!: string;
    icon_values!: any;
    // splashscreen_icon_type!: string;
    splashscreen_icon_value!: any;
    data_id!: any;
}
