import { Docommission } from './docommission';

describe('Docommission', () => {
  it('should create an instance', () => {
    expect(new Docommission()).toBeTruthy();
  });
});
