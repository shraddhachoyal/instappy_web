import { MyAdditionalapp } from './my-additionalapp';

describe('MyAdditionalapp', () => {
  it('should create an instance', () => {
    expect(new MyAdditionalapp()).toBeTruthy();
  });
});
