export class Documents {
    document!: any
    app_uid!: string
}
