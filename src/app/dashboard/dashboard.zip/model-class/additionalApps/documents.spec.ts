import { Documents } from './documents';

describe('Documents', () => {
  it('should create an instance', () => {
    expect(new Documents()).toBeTruthy();
  });
});
