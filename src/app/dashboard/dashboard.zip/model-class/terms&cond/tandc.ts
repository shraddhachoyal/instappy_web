export class Tandc {
}
