import { Tandc } from './tandc';

describe('Tandc', () => {
  it('should create an instance', () => {
    expect(new Tandc()).toBeTruthy();
  });
});
