import { AppName } from './app-name';

describe('AppName', () => {
  it('should create an instance', () => {
    expect(new AppName()).toBeTruthy();
  });
});
