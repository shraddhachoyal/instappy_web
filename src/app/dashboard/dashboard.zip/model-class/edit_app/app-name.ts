export class AppName {
    app_name!: any;
    data_id!: string;
}
