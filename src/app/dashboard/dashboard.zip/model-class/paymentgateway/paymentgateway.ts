export class Paymentgateway {
}
