import { Paymentgateway } from './paymentgateway';

describe('Paymentgateway', () => {
  it('should create an instance', () => {
    expect(new Paymentgateway()).toBeTruthy();
  });
});
