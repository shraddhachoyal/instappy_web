import { Termsconditions } from './termsconditions';

describe('Termsconditions', () => {
  it('should create an instance', () => {
    expect(new Termsconditions()).toBeTruthy();
  });
});
