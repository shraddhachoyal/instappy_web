export class Termsconditions {
    app_uid!: string
    content!: string
    content_type!: number
}
