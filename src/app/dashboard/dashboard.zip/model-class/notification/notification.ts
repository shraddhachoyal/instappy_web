export class Notification {
    app_uid!: string;
    notification_title!: string;
    content!: string;
    image!: string;
    scheduled_date_time!: string;
}
