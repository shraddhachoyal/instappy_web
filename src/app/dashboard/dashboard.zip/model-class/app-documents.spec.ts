import { AppDocuments } from './app-documents';

describe('AppDocuments', () => {
  it('should create an instance', () => {
    expect(new AppDocuments()).toBeTruthy();
  });
});
